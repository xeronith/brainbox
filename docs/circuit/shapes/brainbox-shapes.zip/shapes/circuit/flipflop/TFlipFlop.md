# T-FlipFlop

## Description

The D FlipFLop is widely used. It is also known as a 
*toggle*  flip-flop.

A T flip-flop is a device which swaps or **toggles** state 
every time it is triggered if the T input is asserted, 
otherwise it holds the current output.


The toggle flip-flop is also a frequency divider.