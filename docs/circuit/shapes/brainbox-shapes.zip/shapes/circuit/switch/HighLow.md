# Push Button

toggles the output if the user press 
the mouse button down in the simulation mode.