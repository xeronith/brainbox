# High / Low Array

The High Low Array is a macro object for 8 toggle switches in row.


