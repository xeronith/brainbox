# High / Low Signal display

simple `HIGH`/ `LOW` display.

    HIGH -> red
 
    LOW -> gray