# NOT Gate

## Description
In digital logic, an inverter or `NOT gate` is a logic 
gate which implements logical negation.


## Logic table

| INPUT   |  OUTPUT    |
|:-------:|:----------:|
| Low     |  `High`      |
| `High`    |  Low       |

