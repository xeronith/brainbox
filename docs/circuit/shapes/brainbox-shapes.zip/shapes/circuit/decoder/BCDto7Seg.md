# BCD to 7 Segment Decoder

A **BCD to 7-segment decoder** driver. Its function is to convert 
the logic states at the outputs of a BCD, or binary coded decimal, 
counter like the 4510 into signals which will drive a 7-segment 
display. The display shows the decimal numbers 0-9 and is easily 
understood.